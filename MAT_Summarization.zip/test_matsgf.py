import sys
import os

# Add the project root to sys.path if not running from root module
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from method.MATSGF import MATSGF
from model.Feature import Feature

def test():
    # Define features
    feat_poi_price = Feature("POI_PRICE", ["POI", "price"])
    feat_weather_precip = Feature("WEATHER_PRECIP", ["weather", "precip"])
    
    matsgf = MATSGF(
        trc=0.0,
        trv=0.1, 
        path="data/test_dataset_feat.csv",
        features=[feat_poi_price, feat_weather_precip]
    )
    
    matsgf.execute(
        dir="data/", 
        file="test_dataset_feat_out", 
        lst_categorical_pd=['POI', 'weather', 'label'],
        values_null=['-1'], 
        ignore_columns=[], 
        pattern_date_input='M', 
        rc=0.0, 
        trv=0.1
    )
    print("Execution Finished!")

if __name__ == "__main__":
    test()
